window.onload = function(){
	
	ymaps.ready(function(){
		App.init();
		File.bind(App);
    });

}




