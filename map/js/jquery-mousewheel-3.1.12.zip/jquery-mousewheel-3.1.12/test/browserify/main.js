var $ = require('jquery-browserify');
require('../../jquery.mousewheel.js')($);
